#!/bin/sh

set -e

. /usr/share/openmediavault/scripts/helper-functions

omv_module_set_dirty compose

exit 0

